
Regarding Statamic Add-ons
==========================

Want more Statamic goodness? You're in luck!
Head over to http://statamic.com/resources for just the tip of the iceberg.

Upgrading? We moved Redactor and Truncate into the core and everything else
useful you'll find on our [github account](http://github.com/statamic).

Happy building!