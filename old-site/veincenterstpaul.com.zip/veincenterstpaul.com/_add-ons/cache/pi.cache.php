<?php
class Plugin_cache extends Plugin {

  var $meta = array(
    'name'       => 'Cache',
    'version'    => '1.0.0',
    'author'     => 'Brant Wedel',
    'author_url' => 'http://bitbased.net'
  );

  public function index() {
    $key = $this->fetchParam('key', null, false, false, false);
    $bust = $this->fetchParam('bust', null, false, false, false);

    $cache = $this->cache->get($key.".html", false);
    if($cache == false || $bust == true)
    {
      $cache = Parse::template($this->content, array());
      $this->cache->put($key.".html", $cache);
    }

    return $cache;
  }

}
?>
