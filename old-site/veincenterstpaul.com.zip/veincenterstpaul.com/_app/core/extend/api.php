<?php
abstract class API extends Addon
{
    
}